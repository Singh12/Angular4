import { MenustyleDecoretorDirective } from './menustyle-decoretor.directive';

describe('MenustyleDecoretorDirective', () => {
  it('should create an instance', () => {
    const directive = new MenustyleDecoretorDirective();
    expect(directive).toBeTruthy();
  });
});
