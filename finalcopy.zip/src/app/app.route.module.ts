import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';


import { HomepageComponent } from './core/homepage/homepage.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
const recipeRoute: Routes = [
    {path: '', component: HomepageComponent, pathMatch: 'full'},
    { path: 'recipes', loadChildren: './recipes/recipes.module#RecipeModule'},
    { path: 'shopping-list', component: ShoppingListComponent},
];
@NgModule({
    imports: [RouterModule.forRoot(recipeRoute, { preloadingStrategy: PreloadAllModules})],
    exports: [RouterModule]
})
export class AppRoute {}
