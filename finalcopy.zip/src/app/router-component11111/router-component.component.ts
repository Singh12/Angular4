import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-component',
  templateUrl: './router-component.component.html',
  styleUrls: ['./router-component.component.css']
})
export class RouterComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
