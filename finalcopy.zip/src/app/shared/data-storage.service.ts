import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { RecipeServiceService } from '../recipes/service/recipe-service.service';
import { Recipe } from '../recipes/recipe.model';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AuthServices } from '../auth/auth.service';
import { HttpClient, HttpParams, HttpRequest } from '@angular/common/http';

@Injectable()
export class DataStorageService {
constructor(private http: HttpClient, private recipeService: RecipeServiceService, private authToken: AuthServices) { }
// function to save data

saveRecipe() {
        // return this.http.put('https://recipe-4fc9a.firebaseio.com/recipe.json', this.recipeService.getRecipe(), {
        //     observe: 'body',
        //     params});
        const requests = new HttpRequest('PUT', 'https://recipe-4fc9a.firebaseio.com/recipe.json', this.recipeService.getRecipe(), {reportProgress: true});
        return this.http.request(requests);
}
getRecipe() {
    const token = this.authToken.getAuthToken();
    // We can pass multiple argument
this.http.get<Recipe[]>('https://recipe-4fc9a.firebaseio.com/recipe.json', {
// Below are to optional behavior if response type is not json then change it text
observe: 'body',
responseType: 'json' // text,blob,or file anytype
}).pipe(map((recipes: Recipe[]) => {
            recipes.forEach(recipe => {
                if (!recipe['ingredients']) {
                    recipe['ingredients'] = [];
                }
            });
           return recipes;
        })).subscribe(
            (recipes: Recipe[]) => {
                this.recipeService.setRecipe(recipes);
            }
        );
}
}
