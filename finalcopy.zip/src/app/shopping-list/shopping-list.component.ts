import { Component, OnInit, EventEmitter, OnDestroy } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
import { RecipeShoppingServiceService } from './service/recipe-shopping-service.service';
import { Subscription, Observable } from 'rxjs';
import { Store } from '@ngrx/store';
@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit, OnDestroy {
  // ingredients: Ingredient[];
  // Ingredients will change to observables it won't support as array
  // Observable will get the state after slice in the form of array of ingredients
  shoppingListState: Observable<{ingredients: Ingredient[]}>;
  private subscription: Subscription;
  constructor(private shoppingService: RecipeShoppingServiceService, private store: Store<{shoppingList: {ingredients: Ingredient[]}}>) {
   }
  ngOnInit() {
    // this.ingredients = this.shoppingService.getIngredient();
    this.shoppingListState = this.store.select('shoppingList');
    // this.subscription = this.shoppingService.addIngredient.subscribe(
    //   (ingredients: Ingredient[]) => {
    //     this.ingredients = ingredients;
    //   }
    // );
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getIngredient(index: number) {
    this.shoppingService.toBeUpdating.next(index);
  }
}
