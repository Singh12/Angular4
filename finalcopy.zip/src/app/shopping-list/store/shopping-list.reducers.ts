import * as ShoppingListAction from './shopping-list.actions';
import { Ingredient } from '../../shared/ingredient.model';


const initialState = {
    ingredients: [
        new Ingredient('apple', 5),
        new Ingredient('Tomatoes', 30),
    ]
};
export function shoppingListReducers(state = initialState, action: ShoppingListAction.ShoppingListAction) {
    console.log(action.payload);
    switch (action.type) {
        case ShoppingListAction.ADD_INGREDIENT:
        return {
            ...state,
            ingredients: [...state.ingredients, action.payload]
        };
        default:
         return state;
    }
}
